/* tctest.c - Simple example of TCLink usage.
 *
 * TCLink Copyright (c) 2003 TrustCommerce.
 * http://www.trustcommerce.com
 * developer@trustcommerce.com
 * (626) 744-7700
 * 
 * All code contained herein is copyright (c) TrustCommerce.
 * It is distributed to our clients for your convenience; it is for
 * use by those authorized persons ONLY and for no other purpose beyond
 * integrated with TrustCommerce's payment gateway.
 *
 * That said, please feel free to use this code in any way you see fit for
 * the purpose of TrustCommerce integration.  Should you find any bugs or
 * make interesting improvements/optimizations, please contact us via
 * developer@trustcommerce.com.
 */

#include "tclink.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Insert your custid and password below.
 */

#define CUSTID   "XXXX"
#define PASSWORD "PPPP"

int main()
{
	char buf[1024];

	TCLinkHandle handle = TCLinkCreate();

	printf("Using TCLink version %s\n", TCLinkGetVersion(buf));

	TCLinkPushParam(handle, "custid",   CUSTID);
	TCLinkPushParam(handle, "password", PASSWORD);
	TCLinkPushParam(handle, "action",   "sale");
	TCLinkPushParam(handle, "amount",   "100");                /* $1.00 */
	TCLinkPushParam(handle, "cc",       "4111111111111111");   /* test Visa card */
	TCLinkPushParam(handle, "exp",      "0404");

	TCLinkSend(handle);

	printf("%s", TCLinkGetEntireResponse(handle, buf, sizeof(buf)));

	return 0;
}

